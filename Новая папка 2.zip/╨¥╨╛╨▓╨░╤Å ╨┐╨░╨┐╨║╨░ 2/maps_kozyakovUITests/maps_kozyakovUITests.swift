//
//  maps_Zgorodny__ZyablovUITests.swift
//  maps_Zgorodny_ZyablovUITests
//
//  Created by Даниил on 20.12.2021.
//

import XCTest

class maps_kozyakov: XCTestCase {
    override func setUpWithError() throws {
        continueAfterFailure = false
    }

    override func tearDownWithError() throws {
    }

    func testExample() throws {
        let app = XCUIApplication()
        app.launch()
    }

    func testLaunchPerformance() throws {
        if #available(macOS 10.15, iOS 13.0, tvOS 13.0, watchOS 7.0, *) {
            measure(metrics: [XCTApplicationLaunchMetric()]) {
                XCUIApplication().launch()
            }
        }
    }
}
